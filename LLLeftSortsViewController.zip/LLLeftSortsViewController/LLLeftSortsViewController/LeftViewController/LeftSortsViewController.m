//
//  LeftSortsViewController.m
//  LLLeftSortsViewController
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 zgrb-iOS. All rights reserved.
//

#import "LeftSortsViewController.h"
#import "Config.h"
#import "AppDelegate.h"
#import "ViewController.h"

@interface LeftSortsViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong) NSArray *leftImageAry;
@property(nonatomic,strong) NSArray * leftTextArray;

@end

@implementation LeftSortsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    [self.view addSubview:self.tableview];
    
    UIScrollView *newview =[[UIScrollView alloc]init];
    self.testview = newview;
    newview.frame = self.view.bounds;
    newview.alwaysBounceVertical = YES;
    
    [self.view addSubview:newview];
    
}
#pragma mark 通知 当修改了基本信息后调用
-(void)reloadTableView{
    [self.tableview reloadData];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self reloadTableView];
}
-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self name:RELOADBASEINFO object:nil];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - TableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.leftTextArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *Identifier = @"Identifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Identifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Identifier];
    }
    cell.separatorInset = UIEdgeInsetsZero;
    //    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.font = [UIFont systemFontOfSize:18.0f];
    cell.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [UIColor blackColor];
    [cell.imageView setImage:[UIImage imageNamed:self.leftImageAry[indexPath.row]]];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.text= self.leftTextArray[indexPath.row];

    if (indexPath.row==0) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row==0) {
        return 100;
    }else{
        return 50;
    }
    
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    ViewController *vc = [[ViewController alloc] init];
    [tempAppDelegate.LeftSlideVC closeLeftView];//关闭左侧抽屉
    [tempAppDelegate.mainNavigationController pushViewController:vc animated:NO];
}

#pragma mark-GettersAndSetters
-(NSArray *)leftImageAry {
    
    if (_leftImageAry==nil) {
        _leftImageAry=@[@"user_head",@"user_money",@"user_collect",@"user_store",@"user_share",@"user_share",@"user_setting"];
    }
    return _leftImageAry;
}
-(NSArray *)leftTextArray {
    if (_leftTextArray==nil) {
        _leftTextArray=@[@"我爱你",@"钱包",@"收藏",@"商城",@"推荐1",@"推荐2",@"设置"];
    }
    return _leftTextArray;
}
-(UITableView *)tableview{
    if (_tableview == nil) {
        _tableview = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableview.dataSource = self;
        _tableview.delegate  = self;
        _tableview.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableview.tableFooterView = [UIView new];
    }
    return _tableview;
}

//控制屏幕旋转ios7之后
- (BOOL)shouldAutorotate
{
    return NO;
}
- (UIInterfaceOrientationMask )supportedInterfaceOrientations{
    
    return UIInterfaceOrientationMaskPortrait;
}

//每个屏幕都不旋转
- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return UIInterfaceOrientationMaskPortrait;
}
//iOS7 控制 StatusBar
-(BOOL)prefersStatusBarHidden
{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle
{
    //return [self.topViewController preferredStatusBarStyle];
    //return UIStatusBarStyleLightContent;//白字
    return UIStatusBarStyleDefault;
}
@end

