//
//  LLNavigationViewController.m
//  LLLeftSortsViewController
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 zgrb-iOS. All rights reserved.
//

#import "LLNavigationViewController.h"

@interface LLNavigationViewController ()

@end

@implementation LLNavigationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationBar.barTintColor= [UIColor orangeColor];//设置导航栏背景色
    self.navigationBar.tintColor=[UIColor whiteColor];//设置返回按钮的颜色
    //        修改导航栏的标题 大小  颜色
    [self.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:
                                                [UIColor whiteColor], NSForegroundColorAttributeName,[UIFont systemFontOfSize:19],NSFontAttributeName,nil]];
}

-(BOOL)shouldAutorotate
{
    return self.topViewController.shouldAutorotate;
}

- (UIInterfaceOrientationMask )supportedInterfaceOrientations{
    
    return UIInterfaceOrientationMaskPortrait;
}

//每个屏幕都不旋转
- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return UIInterfaceOrientationMaskPortrait;
}
//iOS7 控制 StatusBar
-(BOOL)prefersStatusBarHidden
{
    return [self.topViewController prefersStatusBarHidden];
}

-(UIStatusBarStyle)preferredStatusBarStyle
{
    //return [self.topViewController preferredStatusBarStyle];
    //return UIStatusBarStyleLightContent;//白字
    return UIStatusBarStyleDefault;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
