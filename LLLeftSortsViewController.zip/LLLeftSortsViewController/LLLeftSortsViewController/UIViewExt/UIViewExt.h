/*
 Erica Sadun, http://ericasadun.com
 iPhone Developer's Cookbook, 3.0 Edition
 BSD License, Use at your own risk
 */

#import <UIKit/UIKit.h>

CGPoint CGRectGetCenter(CGRect rect);
CGRect  CGRectMoveToCenter(CGRect rect, CGPoint center);

@interface UIView (ViewFrameGeometry)
@property CGPoint origin;
@property CGSize size;

@property (readonly) CGPoint bottomLeft;
@property (readonly) CGPoint bottomRight;
@property (readonly) CGPoint topRight;

@property CGFloat height;
@property CGFloat width;

@property CGFloat top;
@property CGFloat left;

@property CGFloat bottom;
@property CGFloat right;

- (void) moveBy: (CGPoint) delta;
- (void) scaleBy: (CGFloat) scaleFactor;
- (void) fitInSize: (CGSize) aSize;


#pragma method -画虚线
//画虚线
-(void)drawDashLine:(UIView *)lineView lineLength:(int)lineLength lineSpacing:(int)lineSpacing lineColor:(UIColor *)lineColor;


#pragma method -默认宽度为@"1"，半径为高度一半的圆角
//设置圆角
-(void)roundView:(UIView *)view  borderColor:(UIColor *)borderColor;
#pragma method -自定义圆角，边框宽度，颜色，半径大小
//自定义
-(void)roundView:(UIView *)view  borderColor:(UIColor *)borderColor borderWidth:(NSInteger )width  cornerRadius:(NSInteger )cornerRaius;
@end