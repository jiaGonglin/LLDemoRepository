//
//  MainPageViewController.h
//  LLLeftSortsViewController
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 zgrb-iOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainPageViewController : UIViewController<UITabBarControllerDelegate>

@property (nonatomic, strong) UIButton * menuBtn;
@property (nonatomic, strong) UIButton * rightBtn;

- (void) setButtonHiddenYES;

- (void) setButtonHiddenNO;

@end


