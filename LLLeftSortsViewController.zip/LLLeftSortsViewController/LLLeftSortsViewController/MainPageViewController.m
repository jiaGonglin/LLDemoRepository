//
//  MainPageViewController.m
//  LLLeftSortsViewController
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 zgrb-iOS. All rights reserved.
//

#import "MainPageViewController.h"
#import "AppDelegate.h"
#import "ViewController.h"
#import "Config.h"

@interface MainPageViewController ()
{
    UITabBarController * tabbarView;
}

@end

@implementation MainPageViewController

#pragma mark-Life Cycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    //主视图背景颜色
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self ShowButtonWithString:nil];
    
    //标签栏按钮
    [self addtabbarlist];
}
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [tempAppDelegate.LeftSlideVC setPanEnabled:NO];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationItem.title = @"设计";
    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [tempAppDelegate.LeftSlideVC setPanEnabled:YES];
    if (tempAppDelegate.LeftSlideVC.closed) {
        [self setButtonHiddenNO];
    }else{
        [self setButtonHiddenYES];
    }
}


#pragma mark initViews and events
-(void)ShowButtonWithString:(NSString *)string{
    //添加左侧
    UIButton *menuBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    menuBtn.frame = CGRectMake(0, 0, 18,20);
    self.menuBtn = menuBtn;
    [menuBtn setBackgroundImage:[UIImage imageNamed:@"top_left"] forState:UIControlStateNormal];
    [menuBtn addTarget:self action:@selector(openOrCloseLeftList) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:menuBtn];
    UIButton *menuBtn1 = [UIButton buttonWithType:UIButtonTypeCustom];
    menuBtn1.frame = CGRectMake(0, 0, 18, 20);
    self.rightBtn = menuBtn1;
    [self.rightBtn setImage:[UIImage imageNamed:@"top_right"] forState:UIControlStateNormal];
    [self.rightBtn addTarget:self action:@selector(rightClick) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:menuBtn1];
}
- (void)openOrCloseLeftList
{
    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    
    if (tempAppDelegate.LeftSlideVC.closed) {
        [tempAppDelegate.LeftSlideVC openLeftView];
        [self setButtonHiddenNO];
    } else {
        [tempAppDelegate.LeftSlideVC closeLeftView];
        [self setButtonHiddenNO];
    }
}
-(void)rightClick{
    AppDelegate *tempAppDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    ViewController *actionVC=[[ViewController alloc]init];
    [tempAppDelegate.mainNavigationController pushViewController: actionVC animated:YES];
}

- (void) setButtonHiddenYES{
    [UIView beginAnimations:nil context:nil];
    _rightBtn.hidden = YES;
    _menuBtn.hidden = YES;
    [UIView commitAnimations];
}

- (void) setButtonHiddenNO{
    [UIView beginAnimations:nil context:nil];
    _rightBtn.hidden = NO;
    _menuBtn.hidden = NO;
    [UIView commitAnimations];
}

#pragma mark-privateMethods

- (void) addtabbarlist{
    
    tabbarView = [[UITabBarController alloc]init];
    tabbarView.delegate = self;
    ViewController* tabbar1 = [[ViewController alloc]init];
    ViewController * tabbar2 = [[ViewController alloc]init];
    ViewController * tabbar3 = [[ViewController alloc]init];
    
    UINavigationController * nav1 = [[UINavigationController alloc]initWithRootViewController:tabbar1];
    UINavigationController * nav2 = [[UINavigationController alloc]initWithRootViewController:tabbar2];
    UINavigationController * nav3 = [[UINavigationController alloc]initWithRootViewController:tabbar3];
    
    UITabBarItem * item1 = [[UITabBarItem alloc]initWithTitle:@"新订单" image:[UIImage imageNamed:@"newOrder_tabbarUnSelect"]selectedImage: [UIImage imageNamed:@"newOrder_tabbarSelect"]];
    UITabBarItem * item2 = [[UITabBarItem alloc]initWithTitle:@"进行中" image:[UIImage imageNamed:@"process_tabbarUnSelect"]selectedImage: [UIImage imageNamed:@"process_tabbarSelect"]];
    UITabBarItem * item3 = [[UITabBarItem alloc]initWithTitle:@"已完成" image:[UIImage imageNamed:@"complete_tabbarUnSelect"]selectedImage: [UIImage imageNamed:@"complete_tabbarSelect"]];
    tabbar1.tabBarItem = item1;
    tabbar2.tabBarItem = item2;
    tabbar3.tabBarItem = item3;
    
    tabbarView.tabBar.tintColor=UICOLOR_FROM_HEX(0xfe8802);
    tabbarView.viewControllers  = @[nav1, nav2,nav3];
    tabbarView.view.frame = self.view.bounds;
    
    [self.view addSubview:tabbarView.view];
}

#pragma mark UITabbarControllerDelegate

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    NSLog(@"第二步");
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    NSLog(@"第一步");
    return YES;
}



-(void)dealloc{
    
}


//控制屏幕旋转ios7之后
- (BOOL)shouldAutorotate
{
    return NO;
}
- (UIInterfaceOrientationMask )supportedInterfaceOrientations{
    
    return UIInterfaceOrientationMaskPortrait;
}

//每个屏幕都不旋转
- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return UIInterfaceOrientationMaskPortrait;
}
//iOS7 控制 StatusBar
-(BOOL)prefersStatusBarHidden
{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle
{
    //return [self.topViewController preferredStatusBarStyle];
    //return UIStatusBarStyleLightContent;//白字
    return UIStatusBarStyleDefault;
}

@end
