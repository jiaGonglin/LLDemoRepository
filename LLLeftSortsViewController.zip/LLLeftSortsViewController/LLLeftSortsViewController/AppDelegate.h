//
//  AppDelegate.h
//  LLLeftSortsViewController
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 zgrb-iOS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LeftSlideViewController.h"
#import "LLNavigationViewController.h"
#import "MainPageViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,strong) LeftSlideViewController *LeftSlideVC;
@property (nonatomic,strong) LLNavigationViewController *mainNavigationController;
@property (nonatomic,strong) MainPageViewController *mainVC;

@end

