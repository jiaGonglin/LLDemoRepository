//
//  Config.h
//
//
//  Created by TXY on 15/10/21.
//  Copyright (c) 2015年 juyi. All rights reserved.
//

#import "UIViewExt.h"

#define SETIMAGE(name) [UIImage imageNamed:(name)]
#define SETFONT(size)[UIFont systemFontOfSize:(size)];
/**
 *  NSUSER_DEFAULT
 */
#define NSUSER_DEFAULT [NSUserDefaults standardUserDefaults]

#define THEMECOLOR  UICOLOR_FROM_HEX(0xff8702)
//#define THEMECOLOR   [UIColor orangeColor]
#define LINECOLOR    UICOLOR_FROM_HEX(0xc6c6c6)


//注册女生显示主题中显示的蓝色
#define COLORBoyGril UICOLOR_FROM_HEX(0x65cfc3)
#define GRAYCOLOR UICOLOR_FROM_HEX(0xf0eff5)
// 黑色字体颜色
#define COLORBlack UICOLOR_FROM_HEX(0x666666)


#define BACKGROUND_COLOR UICOLOR_FROM_HEX(0xF5F5F5)
/**
 *  [UIImage imageNamed:(name)]
 */
#define UIIMAGE_NAMED(name) [UIImage imageNamed:(name)]


// banner的高度
#define BANNER_HEIGHT (150.0/375.0)*SCREEN_WIDTH


/**
 *  r g b 颜色
 */
#define UICOLOR_RGB(r,g,b) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:1]

/**
 *  r g b a 颜色
 */
#define UICOLOR_RGBA(r,g,b,a) [UIColor colorWithRed:(r)/255.0f green:(g)/255.0f blue:(b)/255.0f alpha:(a)]

/**
 *  rgb颜色转换（16进制->UIColor）
 */
#define UICOLOR_FROM_HEX(hex_value) [UIColor colorWithRed:((float)((hex_value & 0xFF0000) >> 16))/255.0 green:((float)((hex_value & 0xFF00) >> 8))/255.0 blue:((float)(hex_value & 0xFF))/255.0 alpha:1.0]

/**
 *  屏幕宽度
 */
#define SCREEN_WIDTH ([UIScreen mainScreen].bounds.size.width)

/**
 *  屏幕高度
 */
#define SCREEN_HEIGHT ([UIScreen mainScreen].bounds.size.height)
// 适配需要的高度
#define SCREEN_HEIGHT1 (([UIScreen mainScreen].bounds.size.height) - 64)

/**
 *  是否是ios7  8 及其以后版本
 */
#define IS_IOS7_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
#define IS_IOS8_LATER ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
/**
 *  [NSString stringWithFormat:@"%@",(a)]
 */
#define NSSTRING_FROM_OBJ(a) ((a) ? [NSString stringWithFormat:@"%@",(a)] : @"")
/**
 * 按钮的高度
 */
#define BTN_HEIGHT 45


/**
 *  当一个对象为 nil 时，返回 @""
 */
#define NSSTRING_EXCLUDE_NIL(str) (str && [str isKindOfClass:[NSString class]] ?str:@"")

//修改基本信息
#define RELOADBASEINFO  @"reload"
