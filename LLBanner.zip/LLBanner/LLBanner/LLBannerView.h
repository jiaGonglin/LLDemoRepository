//
//  LLBannerView.h
//  LLBanner
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 中广瑞波-iOS. All rights reserved.
//

#import <UIKit/UIKit.h>
@class LLBannerView;

@protocol LLBannerViewDelegate <NSObject>
// index从0开始
- (void)banner:(LLBannerView *)banner currentClickedAtIndex:(NSInteger)index;

@end


@interface LLBannerView : UIView

// 加载网络图片，此时初始化时没有请求到网络图片，接口返回图片后加载
- (void)loadImageURLArr:(NSArray *)arr ;
// 加载本地图片
- (void)loadLocalImageNameArr:(NSArray *)arr ;

@property (nonatomic, assign) id<LLBannerViewDelegate>delegate;

/**
 默认图
 */
@property (nonatomic, strong) UIImage *placeholderImage;

/**
 滑动时间，每张图
 */
@property (nonatomic, assign) NSTimeInterval scrollTime;

@end
