//
//  ViewController.h
//  LLBanner
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 中广瑞波-iOS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

