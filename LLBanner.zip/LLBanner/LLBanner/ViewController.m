//
//  ViewController.m
//  LLBanner
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 中广瑞波-iOS. All rights reserved.
//

#import "ViewController.h"
#import "LLBannerView.h"

@interface ViewController ()<LLBannerViewDelegate>
{
    LLBannerView *_bannerView;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //本地图片
    NSMutableArray *dataArr2 = [NSMutableArray array];
    for (NSInteger i=0; i<1; i++) {
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld.png",i+21]];
        [dataArr2 addObject:image];
    }
    
    _bannerView = [[LLBannerView alloc] initWithFrame:CGRectMake(20, 200, self.view.frame.size.width - 40, 240)];
    // 本地图片，因为图片链接为网络请求获得，最好先设置加载本地图片一张，等接口返回数据，在加载网络图片
    [_bannerView loadLocalImageNameArr:dataArr2];
    [self performSelector:@selector(loadImageURL) withObject:nil afterDelay:3];
    _bannerView.delegate = self;
    [self.view addSubview:_bannerView];
    
}
-(void)loadImageURL{
    //网络图片
    NSArray *dataArr = @[@"http://img2.3lian.com/2014/f5/43/d/68.jpg",@"http://file.juzimi.com/shouxiepic/jpzumi.jpg",@"http://a.fssta.com/content/dam/fsdigital/fscom/nba/images/2016/11/09/gettyimages-621672604.vadapt.664.high.711.jpg",@"http://file.juzimi.com/shouxiepic/jazlmo1.jpg"];
    // 网络图片，设置默认图
    _bannerView.placeholderImage = [UIImage imageNamed:@"24.png"];
    [_bannerView loadImageURLArr:dataArr];
}
#pragma mark - JPBannerViewDelegate
- (void)banner:(LLBannerView *)banner currentClickedAtIndex:(NSInteger)index{
    NSLog(@"当前点击的是第%ld页",index);
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
