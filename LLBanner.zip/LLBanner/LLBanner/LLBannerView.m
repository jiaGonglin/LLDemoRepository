//
//  LLBannerView.m
//  LLBanner
//
//  Created by ChinaRainbow-iOS on 2017/12/19.
//  Copyright © 2017年 中广瑞波-iOS. All rights reserved.
//

#import "LLBannerView.h"
#import "UIImageView+WebCache.h"


#define k_Banner_Width _rect.size.width
#define k_Banner_Height _rect.size.height


@interface LLBannerView ()<UIScrollViewDelegate>{
    NSArray *_imageArr;
    NSTimer *_timer;
    CGRect _rect;
    UIPageControl *_pageControl;
}
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIImageView *placeholderView;

@end

@implementation LLBannerView
//加载网络图片的初始化
- (instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _rect = frame;     //Banner的尺寸
        self.scrollTime = 2.5;// 默认2.5s滑动一次
    }
    return self;
}
// 网络图片
- (void)loadImageURLArr:(NSArray *)arr
{
    if (arr.count == 0) {
        return ;
    }
    if (arr.count > 1) {
        [self addTimer];
    }
    [self initWithImageURLArr:arr];
    [self initPageControlWithPageCount:arr.count];
}
// 本地图片
-(void)loadLocalImageNameArr:(NSArray *)arr
{
    if (arr.count == 0) {
        return ;
    }
    if (arr.count > 1) {
        [self addTimer];
    }
    [self initWithImageNameArr:arr];
    [self initPageControlWithPageCount:arr.count];
}

-(void)initPageControlWithPageCount:(NSInteger)pageCount{
    _pageControl = [[UIPageControl alloc] init];
    _pageControl.frame = CGRectMake(k_Banner_Width/2.0-10, k_Banner_Height - 25, 20, 20);//指定位置大小
    _pageControl.numberOfPages = pageCount == 0?1:pageCount;//指定页面个数
    _pageControl.currentPage = 0;//指定pagecontroll的值，默认选中的小白点（第一个）
    //添加委托方法，当点击小白点就执行此方法
    
    _pageControl.pageIndicatorTintColor = [UIColor grayColor];// 设置非选中页的圆点颜色
    
    _pageControl.currentPageIndicatorTintColor = [UIColor yellowColor]; // 设置选中页的圆点颜色
    [self addSubview:_pageControl];
}

#pragma mark - 定时器执行方法
- (void)timerAction{    //定时器：向右移动
    [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x+k_Banner_Width, 0) animated:YES];
}
-(void)setPlaceholderImage:(UIImage *)placeholderImage
{
    _placeholderImage = placeholderImage;
    UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, k_Banner_Width, k_Banner_Height)];
    iv.backgroundColor = [UIColor whiteColor];
    iv.image = placeholderImage;
    self.placeholderView = iv;
    [self addSubview:iv];
}
- (void)initWithImageNameArr:(NSArray *)arr {
    [self.placeholderView removeFromSuperview];
//    [self.scrollView removeFromSuperview];
    NSArray *images = [self addElementToImageArr:arr];
    _imageArr = images;
    self.scrollView.contentSize = CGSizeMake(images.count*k_Banner_Width, 0);
    
    for (NSInteger i=0; i<images.count; i++) {
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(i*k_Banner_Width, 0, k_Banner_Width, k_Banner_Height)];
        iv.backgroundColor = [UIColor whiteColor];
        iv.image = images[i];
        [self.scrollView addSubview:iv];
    }
    //添加点击手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    [self.scrollView addGestureRecognizer:tap];
    
    [self addSubview:self.scrollView];
}
- (void)initWithImageURLArr:(NSArray *)arr {
    [self.placeholderView removeFromSuperview];
//    [self.scrollView removeFromSuperview];

    NSArray *images = [self addElementToImageArr:arr];
    _imageArr = images;
    self.scrollView.contentSize = CGSizeMake(images.count*k_Banner_Width, 0);
    
    
    for (NSInteger i=0; i<images.count; i++) {
        UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(i*k_Banner_Width, 0, k_Banner_Width, k_Banner_Height)];
        iv.backgroundColor = [UIColor whiteColor];
        NSString *urlString = images[i];
        if (![images[i] isKindOfClass:[NSString class]]) {
            urlString = @"";
        }
        [iv sd_setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:self.placeholderImage];
        [self.scrollView addSubview:iv];
    }
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction)];
    [self.scrollView addGestureRecognizer:tap];
    
    [self addSubview:self.scrollView];
}
- (void)tapAction{
    NSInteger count = self.scrollView.contentOffset.x/k_Banner_Width;
    if ([self.delegate respondsToSelector:@selector(banner:currentClickedAtIndex:)]) {
        [self.delegate banner:self currentClickedAtIndex:count-1];
    }
}
#pragma mark - 数组的修改，收尾添加元素
- (NSArray *)addElementToImageArr:(NSArray *)arr{
    NSString *url1 = [arr firstObject];
    NSString *url2 = [arr lastObject];
    
    NSMutableArray *tempArr = [NSMutableArray arrayWithArray:arr];
    [tempArr insertObject:url2 atIndex:0];
    [tempArr addObject:url1];
    
    return (NSArray *)tempArr;
}
//本方法是控制轮播图无限循环的关键代码
- (void)updateScrollCurrentPages:(CGFloat)content_X{
    CGFloat factor = content_X/k_Banner_Width;
    if (factor >= _imageArr.count-1) {
        self.scrollView.contentOffset = CGPointMake(k_Banner_Width, 0);
    }else if(factor<=0){
        self.scrollView.contentOffset = CGPointMake((_imageArr.count-2)*k_Banner_Width, 0);
    }
    if (_imageArr.count == 0) {
        return;
    }
    NSInteger count = self.scrollView.contentOffset.x/k_Banner_Width;
    
    _pageControl.currentPage = count - 1;
    //    NSLog(@"%ld,%ld,%ld",count,_imageArr.count,(long)_pageControl.currentPage);
    
}
#pragma mark - ScrollViewDelegate
/**
 *  在手指已经开始拖拽的时候移除定时器
 *  @param scrollView 滑动试图
 */
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self removeTimer];
}
/**
 *  在手指已经停止拖拽的时候添加定时器
 *  @param scrollView 滑动试图
 *  @param decelerate 是否有减速效果
 */
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
    [self addTimer];
}
/**
 *  当滑动试图停止减速（停止）调用（用于手动拖拽）
 *  @param scrollView 滑动试图
 */
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    [self updateScrollCurrentPages:scrollView.contentOffset.x];
    
}
/**
 当滑动试图停止减速调用（用于定时器）
 @param scrollView 滑动试图
 */
- (void)scrollViewDidEndScrollingAnimation:(UIScrollView *)scrollView{
    [self updateScrollCurrentPages:scrollView.contentOffset.x];
}


- (void)addTimer{
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:self.scrollTime target:self selector:@selector(timerAction) userInfo:nil repeats:YES];
        //设置RunLoop模式，保证tableView拖动的时候定时器仍然在运行
        [[NSRunLoop currentRunLoop] addTimer:_timer forMode:NSRunLoopCommonModes];
    }
    
}
- (void)removeTimer{
    [_timer invalidate];
    _timer = nil;
}
- (void)dealloc{
    [self removeTimer];
}
-(UIScrollView *)scrollView{
    if (_scrollView == nil) {
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake( 0, 0, k_Banner_Width, k_Banner_Height)];
        _scrollView.contentOffset = CGPointMake(k_Banner_Width, 0);
        _scrollView.bounces = NO;
        _scrollView.pagingEnabled = YES;
        _scrollView.delegate = self;
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.showsHorizontalScrollIndicator = NO;
        _scrollView.backgroundColor = [UIColor whiteColor];
    }
    return _scrollView;
}

@end
